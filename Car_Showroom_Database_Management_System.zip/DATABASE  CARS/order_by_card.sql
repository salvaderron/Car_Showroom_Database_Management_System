-- MySQL dump 10.13  Distrib 5.1.35, for Win32 (ia32)
--
-- Host: localhost    Database: cars
-- ------------------------------------------------------
-- Server version	5.1.35-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `name` varchar(50) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `carname` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `passport_id` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `PINCODE` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('RON','MANAGER','8947036824','32000000','AUDI  R8','2001-08-13','A11B222C33D55','A-114,MODEL TOWN','JAIPUR','RAJASTHAN','302017'),('RAMAN','CLERK','1234567890','1900000','SECOND HAND MERCEDEZ','1990-05-05','S55S5S5S5S','5/10,MALVIYA NAGAR','JAIPUR','RAJASTHAN','302017'),('AMAN','TEACHER','9876543210','5300000','Ford shelby(MUSTANG)','1988-07-17','A885SW2W822W','D-46,VAISHALI NAGAR','JAIPUR','RAJASTHAN','302017'),('DK','DON','6665552220','2500000','SECOND HAND CAMRO','1991-03-04','A5A55AS525S','8/21,ANDHERI','MUMBAI','MAHARASHTRA','853271');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `e_id` varchar(12) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mobileno` varchar(10) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`e_id`),
  UNIQUE KEY `mobileno` (`mobileno`),
  UNIQUE KEY `password` (`PASSWORD`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('8947036824','RON','A-114,MODEL TOWN','8947036824','2001-08-13','6824',200000),('9799476717','AMIT','C/10,MALVIYA NAGAR','9799476717','1988-10-15','1234',1500000);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `name` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `mobileno` varchar(12) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `car_chosen` varchar(50) DEFAULT NULL,
  `COMMENT` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES ('RON','JAIPUR','8647036824',4,'AUDI  R8','GOOOD . I AM HAPPY!!!'),('AMAN','AJMER','1234567890',3,'Chevrolet Camaro 2SS Convertible ','HAPPYYYYY'),('MOHAN','ALWAR','9876543210',5,'KOENIGSEGG  AGERA','GOOOD WORKING'),('DK','MUMBAI','8947036824',5,'KOENIGSEGG  AGERA','VERY GOOD PROGRAMMING.\nAND GOOD CAR IS BEING SELLED. STAY BLESSED'),('AAYUSHI','JAIPUR','9426587325',4,'Bentley Continental','VERY GOOD AND EFFECTIVE  WORKING');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `managers`
--

DROP TABLE IF EXISTS `managers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `managers` (
  `M_ID` varchar(12) NOT NULL DEFAULT '',
  `NAME` varchar(50) DEFAULT NULL,
  `ADDRESS` varchar(100) DEFAULT NULL,
  `MOBILENO` varchar(11) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`M_ID`),
  UNIQUE KEY `PASSWORD` (`PASSWORD`),
  UNIQUE KEY `MOBILENO` (`MOBILENO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `managers`
--

LOCK TABLES `managers` WRITE;
/*!40000 ALTER TABLE `managers` DISABLE KEYS */;
INSERT INTO `managers` VALUES ('8947036824','RON','A-114,MODEL TOWN','8947036824','6824'),('9876543210','AAYUSHI','8/10,VAISHALI NAGAR','9876543210','1234');
/*!40000 ALTER TABLE `managers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_by_bank`
--

DROP TABLE IF EXISTS `order_by_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_by_bank` (
  `c_name` varchar(50) DEFAULT NULL,
  `carname` varchar(50) DEFAULT NULL,
  `PRICE` varchar(50) DEFAULT NULL,
  `bank_name` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) NOT NULL,
  PRIMARY KEY (`account_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_by_bank`
--

LOCK TABLES `order_by_bank` WRITE;
/*!40000 ALTER TABLE `order_by_bank` DISABLE KEYS */;
INSERT INTO `order_by_bank` VALUES ('RON','VOLVO  S60-R DESIGN','2800000','ICICI','451298763256'),('RON','AUDI  R8','32000000','ICICI','7896541252367419'),('SEBASTIANA','Lamborghini Gallardo','28000000','ICICI','8965745231648526');
/*!40000 ALTER TABLE `order_by_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_by_card`
--

DROP TABLE IF EXISTS `order_by_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_by_card` (
  `c_name` varchar(50) DEFAULT NULL,
  `carname` varchar(50) DEFAULT NULL,
  `PRICE` varchar(50) DEFAULT NULL,
  `name_on_card` varchar(50) DEFAULT NULL,
  `expiry_date` varchar(50) DEFAULT NULL,
  `card_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_by_card`
--

LOCK TABLES `order_by_card` WRITE;
/*!40000 ALTER TABLE `order_by_card` DISABLE KEYS */;
INSERT INTO `order_by_card` VALUES ('ron','KOENIGSEGG  AGERA','8000000','salvader','2001-8','9874563214528967'),('RAMAN','MERCEDEZ','1900000','RAMAN','1990-5','456123078954'),('AMAN','Ford shelby(MUSTANG)','5300000','AMAN','1988-7','99887766554433221100'),('DK','CAMRO','2500000','DAYAVAN','1991-3','852369741025');
/*!40000 ALTER TABLE `order_by_card` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-09  0:19:15
