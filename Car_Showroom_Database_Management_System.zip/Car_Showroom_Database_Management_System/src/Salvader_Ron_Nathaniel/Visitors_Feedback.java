
package Salvader_Ron_Nathaniel;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Visitors_Feedback extends javax.swing.JFrame {

    /** Creates new form Visitors_Feedback */
    public Visitors_Feedback() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        submitButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        checkReviewButton = new javax.swing.JButton();
        jComboBox4 = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("VISITOR'S  FEEDBACK");
        setResizable(false);
        getContentPane().setLayout(null);

        jLabel2.setBackground(new java.awt.Color(0, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 14));
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setText("                VISITOR'S    FEEDBACK");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(190, 20, 360, 17);

        jLabel3.setBackground(new java.awt.Color(0, 255, 255));
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("NAME");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(30, 70, 50, 14);

        jLabel4.setBackground(new java.awt.Color(0, 255, 255));
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setText("CITY");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(400, 70, 60, 14);

        jLabel5.setBackground(new java.awt.Color(0, 255, 255));
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setText("MOBILE NO.");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 390, 70, 14);

        jLabel6.setForeground(new java.awt.Color(255, 255, 0));
        jLabel6.setText("HOW WAS YOUR EXPERIENCE WITH US?");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(10, 110, 310, 20);

        jLabel7.setForeground(new java.awt.Color(255, 255, 0));
        jLabel7.setText("CAR CHOSEN");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(380, 370, 80, 14);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(210, 70, 160, 20);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(490, 70, 160, 20);

        jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField3KeyTyped(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(170, 390, 160, 20);

        jRadioButton1.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setForeground(new java.awt.Color(255, 255, 0));
        jRadioButton1.setText("1");
        getContentPane().add(jRadioButton1);
        jRadioButton1.setBounds(10, 140, 40, 23);

        jRadioButton2.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setForeground(new java.awt.Color(255, 255, 0));
        jRadioButton2.setText("2");
        getContentPane().add(jRadioButton2);
        jRadioButton2.setBounds(80, 140, 50, 23);

        jRadioButton3.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setForeground(new java.awt.Color(255, 255, 0));
        jRadioButton3.setText("3");
        getContentPane().add(jRadioButton3);
        jRadioButton3.setBounds(150, 140, 50, 23);

        jRadioButton4.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setForeground(new java.awt.Color(255, 255, 0));
        jRadioButton4.setText("4");
        getContentPane().add(jRadioButton4);
        jRadioButton4.setBounds(200, 140, 50, 23);

        jRadioButton5.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton5);
        jRadioButton5.setForeground(new java.awt.Color(255, 255, 0));
        jRadioButton5.setText("5");
        jRadioButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton5);
        jRadioButton5.setBounds(260, 140, 40, 23);

        submitButton.setBackground(new java.awt.Color(0, 0, 0));
        submitButton.setForeground(new java.awt.Color(255, 255, 0));
        submitButton.setText("SUBMIT");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(submitButton);
        submitButton.setBounds(20, 450, 120, 23);

        jLabel8.setForeground(new java.awt.Color(255, 255, 0));
        jLabel8.setText("COMMENT");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(380, 410, 90, 14);

        jTextArea1.setColumns(20);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(490, 400, 190, 70);

        checkReviewButton.setBackground(new java.awt.Color(0, 0, 0));
        checkReviewButton.setForeground(new java.awt.Color(255, 255, 0));
        checkReviewButton.setText("CHECK  REVIEW");
        checkReviewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkReviewButtonActionPerformed(evt);
            }
        });
        getContentPane().add(checkReviewButton);
        checkReviewButton.setBounds(180, 450, 140, 23);

        jComboBox4.setFont(new java.awt.Font("Rockwell", 3, 10));
        jComboBox4.setForeground(new java.awt.Color(153, 153, 0));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "AUDI  R8", "Audi S1", "Bentley Continental", "BMW M6 Coupe", "BMW M3", "Chevrolet Camaro 2SS Convertible ", "Infiniti IPL G Convertible", "Jaguar XK Special Edition", "Lamborghini Gallardo", "Lamborghini Aventado", "Maserati MC Sport Line", "Ford shelby(MUSTANG)", "HYUNDAI  ELITE  i20", "HONDA JAZZ", "HONDA MOBILIO", "VOLVO  S60-R DESIGN", "( SECOND HAND CARS )", "AUDI  S1", "BMW", "CAMRO", "KOENIGSEGG  AGERA", "MERCEDEZ" }));
        getContentPane().add(jComboBox4);
        jComboBox4.setBounds(490, 370, 194, 19);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/VISITOR'S  FEEDBACK.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 740, 490);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-734)/2, (screenSize.height-514)/2, 734, 514);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jRadioButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton5ActionPerformed

    private void jTextField3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField3KeyTyped
       char ch;
       ch=evt.getKeyChar();
       if(ch>=48 && ch<=57)
       {}
       else
       {
           evt.consume();
       }
    }//GEN-LAST:event_jTextField3KeyTyped

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
     if (jTextField1.getText().isEmpty()&&jTextField2.getText().isEmpty()&&jTextField3.getText().isEmpty()&&jTextArea1.getText().isEmpty())
     {
        JOptionPane.showMessageDialog(null,"PLEASE ENTER ALL THE FOLLOWING INFORMATION");
     }
  else
     {
      String name,city,mobile,car,comment;
      int rating = 0;
      name=jTextField1.getText();
      city=jTextField2.getText();
      mobile=jTextField3.getText();
      car=(String)jComboBox4.getSelectedItem();
      comment=jTextArea1.getText();
      if(jRadioButton1.isSelected())
         rating=1;
      else  if(jRadioButton2.isSelected())
         rating=2;
     else  if(jRadioButton3.isSelected())
         rating=3;
     else  if(jRadioButton4.isSelected())
         rating=4;
     else  if(jRadioButton5.isSelected())
         rating=5;

      try
        {
            Class.forName("java.sql.DriverManager");
            Connection c;
            c=DriverManager.getConnection("jdbc:mysql://localhost/cars","root","123");
            Statement s;
            s=c.createStatement();
            String query;
            query="INSERT INTO FEEDBACK VALUE('"+name+"','"+city+"','"+mobile+"','"+rating+"','"+car+"','"+comment+"');";
            s.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"THANK  YOU  FOR  YOUR  FEEDBACK");
            Main_Menu m1=new  Main_Menu();
            m1.setVisible(true);
            this.dispose();
        }
   catch (Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
       }
}//GEN-LAST:event_submitButtonActionPerformed

    private void checkReviewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkReviewButtonActionPerformed
     Check_Review  c1=new  Check_Review();
     c1.setVisible(true);
     this.dispose();
}//GEN-LAST:event_checkReviewButtonActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Visitors_Feedback().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton checkReviewButton;
    private javax.swing.JComboBox jComboBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JButton submitButton;
    // End of variables declaration//GEN-END:variables

}
