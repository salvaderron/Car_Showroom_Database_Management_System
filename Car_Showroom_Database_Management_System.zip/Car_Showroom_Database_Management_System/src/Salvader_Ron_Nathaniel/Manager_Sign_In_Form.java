package Salvader_Ron_Nathaniel;

import java.sql.*;
import javax.swing.JOptionPane;



public class Manager_Sign_In_Form extends javax.swing.JFrame {

    /** Creates new form Mananger_Sign_in_Form */
    public Manager_Sign_In_Form() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        userTextField = new javax.swing.JTextField();
        pwdPasswordField = new javax.swing.JPasswordField();
        backToMainMenuButton = new javax.swing.JButton();
        signInButton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        signUpButton = new javax.swing.JButton();
        showPasswordCheckBox = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("MANAGER SIGN IN FORM");
        setResizable(false);
        getContentPane().setLayout(null);

        jLabel2.setBackground(new java.awt.Color(51, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 18));
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setText("          ENTER YOUR  CREDENTIALS");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(260, 30, 360, 22);

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 18));
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("ENTER USERNAME");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(150, 80, 230, 22);

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 18));
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setText("ENTER PASSWORD");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(150, 140, 210, 20);

        userTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                userTextFieldKeyTyped(evt);
            }
        });
        getContentPane().add(userTextField);
        userTextField.setBounds(400, 80, 220, 26);

        pwdPasswordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pwdPasswordFieldActionPerformed(evt);
            }
        });
        getContentPane().add(pwdPasswordField);
        pwdPasswordField.setBounds(400, 140, 220, 26);

        backToMainMenuButton.setBackground(new java.awt.Color(0, 255, 255));
        backToMainMenuButton.setFont(new java.awt.Font("Tahoma", 3, 24));
        backToMainMenuButton.setForeground(new java.awt.Color(255, 0, 0));
        backToMainMenuButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/BACKWARD  BLACK.png"))); // NOI18N
        backToMainMenuButton.setOpaque(false);
        backToMainMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToMainMenuButtonActionPerformed(evt);
            }
        });
        getContentPane().add(backToMainMenuButton);
        backToMainMenuButton.setBounds(0, 10, 40, 30);

        signInButton.setBackground(new java.awt.Color(0, 0, 0));
        signInButton.setForeground(new java.awt.Color(255, 255, 0));
        signInButton.setText("SIGN IN");
        signInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signInButtonActionPerformed(evt);
            }
        });
        getContentPane().add(signInButton);
        signInButton.setBounds(150, 450, 220, 30);

        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setEnabled(false);
        getContentPane().add(jLabel5);
        jLabel5.setBounds(630, 80, 140, 20);

        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setEnabled(false);
        getContentPane().add(jLabel6);
        jLabel6.setBounds(630, 140, 150, 20);

        signUpButton.setBackground(new java.awt.Color(0, 0, 0));
        signUpButton.setForeground(new java.awt.Color(255, 255, 0));
        signUpButton.setText("SIGN UP");
        signUpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signUpButtonActionPerformed(evt);
            }
        });
        getContentPane().add(signUpButton);
        signUpButton.setBounds(590, 450, 200, 29);

        showPasswordCheckBox.setBackground(new java.awt.Color(0, 0, 0));
        showPasswordCheckBox.setFont(new java.awt.Font("Tahoma", 3, 18));
        showPasswordCheckBox.setForeground(new java.awt.Color(255, 255, 0));
        showPasswordCheckBox.setText("SHOW PASSWORD");
        showPasswordCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPasswordCheckBoxActionPerformed(evt);
            }
        });
        getContentPane().add(showPasswordCheckBox);
        showPasswordCheckBox.setBounds(400, 170, 220, 20);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MANAGER SIGN IN.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 920, 520);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-922)/2, (screenSize.height-553)/2, 922, 553);
    }// </editor-fold>//GEN-END:initComponents

    private void pwdPasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pwdPasswordFieldActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_pwdPasswordFieldActionPerformed

    private void backToMainMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToMainMenuButtonActionPerformed
        Main_Menu m1=new Main_Menu();
        m1.setVisible(true);
        this.dispose();
}//GEN-LAST:event_backToMainMenuButtonActionPerformed

    private void signInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signInButtonActionPerformed
        if(userTextField.getText().isEmpty())
        {
            jLabel5.setText("ENTER USERNAME");
            jLabel6.setText(" ");
        }
        if(pwdPasswordField.getText().isEmpty())
        {
            jLabel5.setText(" ");
            jLabel6.setText("ENTER  PASSWORD");
        }
        if(userTextField.getText().isEmpty() && pwdPasswordField.getText().isEmpty())
        {
            jLabel5.setText("ENTER USERNAME ");
            jLabel6.setText("ENTER PASSWORD ");
        }
        else
        {
            String user=userTextField.getText();
            String pwd=pwdPasswordField.getText();
            try
            {
                Class.forName("java.sql.DriverManager");
                Connection c;
                c=DriverManager.getConnection("jdbc:mysql://localhost/cars","root","123");
                Statement s;
                s=c.createStatement();
                String query="select name,password from managers where name='"+user+"' and password='"+pwd+"';";
                ResultSet rs;
                rs=s.executeQuery(query);
                if(rs.next())
                {
                    Manager_Main_Menu m1=new  Manager_Main_Menu();
                    m1.setVisible(true);
                    this.dispose();
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"WRONG USERNAME OR PASSWORD.");
                }
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null,e.getMessage());
            }
        }
}//GEN-LAST:event_signInButtonActionPerformed

    private void signUpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signUpButtonActionPerformed
        Manager_Sign_Up_Form  m1=new Manager_Sign_Up_Form();
        m1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_signUpButtonActionPerformed

    private void userTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_userTextFieldKeyTyped
      
    }//GEN-LAST:event_userTextFieldKeyTyped

    private void showPasswordCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPasswordCheckBoxActionPerformed
        if(showPasswordCheckBox.isSelected()) {
            pwdPasswordField.setEchoChar((char)0);
        } else {
            pwdPasswordField.setEchoChar('*');
        }
}//GEN-LAST:event_showPasswordCheckBoxActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manager_Sign_In_Form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backToMainMenuButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPasswordField pwdPasswordField;
    private javax.swing.JCheckBox showPasswordCheckBox;
    private javax.swing.JButton signInButton;
    private javax.swing.JButton signUpButton;
    private javax.swing.JTextField userTextField;
    // End of variables declaration//GEN-END:variables

}
