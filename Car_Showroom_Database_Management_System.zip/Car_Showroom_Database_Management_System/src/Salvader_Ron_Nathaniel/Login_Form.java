

package Salvader_Ron_Nathaniel;


public class Login_Form extends javax.swing.JFrame {

    /** Creates new form Login_Form */
    public Login_Form() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        managerRadioButton = new javax.swing.JRadioButton();
        employeeRadioButton = new javax.swing.JRadioButton();
        customerRadioButton = new javax.swing.JRadioButton();
        backToMainMenuButton = new javax.swing.JButton();
        adminLoginadioButton = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("LOGIN FORM");
        setResizable(false);
        getContentPane().setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 204, 204));
        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("LOGIN   AS");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(310, 20, 360, 120);

        managerRadioButton.setBackground(new java.awt.Color(204, 204, 204));
        buttonGroup1.add(managerRadioButton);
        managerRadioButton.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        managerRadioButton.setForeground(new java.awt.Color(255, 0, 0));
        managerRadioButton.setText("MANAGER");
        managerRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                managerRadioButtonActionPerformed(evt);
            }
        });
        getContentPane().add(managerRadioButton);
        managerRadioButton.setBounds(40, 560, 155, 37);

        employeeRadioButton.setBackground(new java.awt.Color(204, 204, 204));
        buttonGroup1.add(employeeRadioButton);
        employeeRadioButton.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        employeeRadioButton.setForeground(new java.awt.Color(255, 0, 0));
        employeeRadioButton.setText("EMPLOYEE");
        employeeRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeRadioButtonActionPerformed(evt);
            }
        });
        getContentPane().add(employeeRadioButton);
        employeeRadioButton.setBounds(370, 560, 163, 37);

        customerRadioButton.setBackground(new java.awt.Color(204, 204, 204));
        buttonGroup1.add(customerRadioButton);
        customerRadioButton.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        customerRadioButton.setForeground(new java.awt.Color(255, 0, 0));
        customerRadioButton.setText("CUSTOMER");
        customerRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customerRadioButtonActionPerformed(evt);
            }
        });
        getContentPane().add(customerRadioButton);
        customerRadioButton.setBounds(710, 560, 167, 37);

        backToMainMenuButton.setBackground(new java.awt.Color(0, 255, 255));
        backToMainMenuButton.setFont(new java.awt.Font("Tahoma", 3, 24));
        backToMainMenuButton.setForeground(new java.awt.Color(255, 0, 0));
        backToMainMenuButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/BACKWARD  WHITE.png"))); // NOI18N
        backToMainMenuButton.setOpaque(false);
        backToMainMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToMainMenuButtonActionPerformed(evt);
            }
        });
        getContentPane().add(backToMainMenuButton);
        backToMainMenuButton.setBounds(10, 10, 40, 40);

        adminLoginadioButton.setBackground(new java.awt.Color(204, 204, 204));
        adminLoginadioButton.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        adminLoginadioButton.setForeground(new java.awt.Color(255, 0, 0));
        adminLoginadioButton.setText("ADMIN LOGIN");
        adminLoginadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminLoginadioButtonActionPerformed(evt);
            }
        });
        getContentPane().add(adminLoginadioButton);
        adminLoginadioButton.setBounds(723, 10, 210, 37);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LOGIN FORM.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 960, 600);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-965)/2, (screenSize.height-638)/2, 965, 638);
    }// </editor-fold>//GEN-END:initComponents

    private void customerRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customerRadioButtonActionPerformed
      Customer_Main_Menu c1=new  Customer_Main_Menu();
      c1.setVisible(true);
      this.dispose();
}//GEN-LAST:event_customerRadioButtonActionPerformed

    private void managerRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_managerRadioButtonActionPerformed
      Manager_Sign_In_Form m1=new  Manager_Sign_In_Form();
      m1.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_managerRadioButtonActionPerformed

    private void employeeRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeRadioButtonActionPerformed
      Employee_Sign_In_Form e1=new  Employee_Sign_In_Form();
      e1.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_employeeRadioButtonActionPerformed

    private void backToMainMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToMainMenuButtonActionPerformed
        Main_Menu m1=new Main_Menu();
        m1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backToMainMenuButtonActionPerformed

    private void adminLoginadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminLoginadioButtonActionPerformed
        Admin_Login a1=new Admin_Login();
        a1.setVisible(true);
        this.dispose();
}//GEN-LAST:event_adminLoginadioButtonActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login_Form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton adminLoginadioButton;
    private javax.swing.JButton backToMainMenuButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton customerRadioButton;
    private javax.swing.JRadioButton employeeRadioButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JRadioButton managerRadioButton;
    // End of variables declaration//GEN-END:variables

}
